﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_E
{
    public class ProductoE
    {
        public int id_producto { get; set; }
        public string nombre_producto { get; set; }
        public bool activo { get; set; }
    }
}
